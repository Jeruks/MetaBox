<?php 
$conn = mysqli_connect('localhost', 'root', '', 'metabox') or die ('Gagal terhubung ke database');


?>